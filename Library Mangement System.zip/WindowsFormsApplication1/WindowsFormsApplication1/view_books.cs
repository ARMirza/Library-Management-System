﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class view_books : Form
    {
        private SqlConnection xConn;
        public view_books()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
        }

        private void view_books_Load(object sender, EventArgs e)
        {
            disp_books();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                xConn.Open();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("select * from books where Books_Name like('%"+ textBox1.Text +"%')", xConn).Fill(xTable);
                dataGridView1.DataSource = xTable;

                xConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            int i = 0;
            try
            {

                xConn.Open();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("select * from books where Books_Name like('%" + textBox1.Text + "%')", xConn).Fill(xTable);
                i= Convert.ToInt32(xTable.Rows.Count.ToString());
                dataGridView1.DataSource = xTable;

                xConn.Close();
                if (i == 0)
                {
                    MessageBox.Show("No Books Found");
                    textBox1.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel2.Visible = true;
            int i;
            i =Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            try
            {

                xConn.Open();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("select * from books where ID=" + i + "", xConn).Fill(xTable);

                foreach (DataRow dr in xTable.Rows)
                {
                    booksname.Text=dr["Books_Name"].ToString();
                    authorname.Text = dr["Author_Name"].ToString();
                    dateTimePicker1.Value = Convert.ToDateTime(dr["Purchase_Date"].ToString());
                    booksprice.Text = dr["Price"].ToString();
                    quantity.Text = dr["Quantity"].ToString();
                }

                xConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            try
            {
                xConn.Open();
                new SqlCommand(" update books set Books_Name='" + booksname.Text + "',Author_Name='" + authorname.Text + "',Purchase_Date='" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "',Price=" + booksprice.Text + ",Quantity=" + quantity.Text + ",Available_Quantity=" + quantity.Text + " where id=" + i + "", xConn).ExecuteNonQuery();
                xConn.Close();
                disp_books();
                MessageBox.Show("Record updated successfully");
                
                panel2.Visible = false;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void disp_books()
        {
            try
            {

                xConn.Open();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("select * from books", xConn).Fill(xTable);
                dataGridView1.DataSource = xTable;

                xConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
