﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Borrow_Books : Form
    {
        private SqlConnection xConn;
        public Borrow_Books()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            xConn.Open();
            int i = 0;
            DataTable xTable =new DataTable();
            new SqlDataAdapter("select * from Member where ID='"+txt_ID.Text +"'",xConn).Fill(xTable);
            i = Convert.ToInt32(xTable.Rows.Count.ToString());
            if (i == 0)
            {
                MessageBox.Show("Member not found");
            }
            else
            {

                foreach (DataRow dr in xTable.Rows)
                {
                    txt_memname.Text=dr["Member_Name"].ToString();
                    txt_memcontact.Text = dr["Member_Contact"].ToString();
                    txt_mememail.Text = dr["Member_Email"].ToString();
                }
                
            }
            xConn.Close();
        }

        private void txt_booksname_KeyUp(object sender, KeyEventArgs e)
        {
            int count = 0;
            
            if (e.KeyCode != Keys.Enter)
            {
                listBox1.Items.Clear();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("Select * from Books where Books_Name like('%" + txt_booksname.Text + "%')", xConn).Fill(xTable);
                count = Convert.ToInt32(xTable.Rows.Count.ToString());
                if (count > 0)
                {
                    listBox1.Visible = true;
                    foreach (DataRow dr in xTable.Rows)
                    {
                        listBox1.Items.Add(dr["Books_Name"].ToString());
                    }
                }
            }
            
        }

        private void txt_booksname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                listBox1.Focus();
                listBox1.SelectedIndex = 0;
            }
        }

        private void listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txt_booksname.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            txt_booksname.Text = listBox1.SelectedItem.ToString();
            listBox1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            xConn.Open();
            int qty = 0;
             DataTable xTable3 = new DataTable();
            new SqlDataAdapter("select * from books where books_name='"+txt_booksname.Text +"'",xConn).Fill(xTable3);
            foreach (DataRow dr2 in xTable3.Rows)
            {
               qty =Convert.ToInt32(dr2["available_quantity"].ToString());
            }
            if (qty > 0)
            {
                new SqlCommand("insert into Borrow_Books values(" + txt_ID.Text + ",'" + txt_memname.Text + "','" + txt_memcontact.Text + "','" + txt_mememail.Text + "','" + txt_booksname.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','')", xConn).ExecuteNonQuery();
                new SqlCommand("update books set available_quantity=available_quantity-1 where books_name='" + txt_booksname.Text + "'", xConn).ExecuteNonQuery();
                xConn.Close();
                MessageBox.Show("Book Issued Successfully");
            }
            else
            {
                MessageBox.Show("Book not available");
            }
            
        }
    }
}
