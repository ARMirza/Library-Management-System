﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;

namespace WindowsFormsApplication1
{
    public partial class Books_Taken : Form
    {
        private SqlConnection xConn;
        public Books_Taken()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
        }
        public void fill_books()
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("select Books_Name,Author_Name,Quantity,Available_Quantity from Books",xConn).Fill(xTable);
            dataGridView1.DataSource = xTable;
        }
        private void Books_Taken_Load(object sender, EventArgs e)
        {
            fill_books();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string i;
            i = dataGridView1.SelectedCells[0].Value.ToString();
            DataTable xTable = new DataTable();
            new SqlDataAdapter("select * from Borrow_Books where Books_Name='"+i.ToString() +"' and Return_Date='' ", xConn).Fill(xTable);
            dataGridView2.DataSource = xTable;
        
        }
        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("select Books_Name,Author_Name,Quantity,Available_Quantity from Books where Books_Name like('%"+textBox1.Text +"%')", xConn).Fill(xTable);
            dataGridView1.DataSource = xTable;
        }
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string i;
            i = dataGridView2.SelectedCells[4].Value.ToString();
            textBox2.Text = i.ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SmtpClient smtp= new SmtpClient("smtp.gmail.com",587);
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            //(username,password)
            smtp.Credentials = new NetworkCredential("email dalni hai", "password dalna hai");    
            //(from,to,subject,body)
            MailMessage mail = new MailMessage("email dalni hai", textBox2.Text, "Book Return Notice ", textBox3.Text);
            mail.Priority = MailPriority.High;
            smtp.Send(mail);
            MessageBox.Show("Mail Send");            
        }
      
    }
}
