﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Add_Books : Form
    {
        private SqlConnection xConn;
        public Add_Books()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            xConn.Open();
            new SqlCommand(" insert into Books values('" + textBox1.Text + "','" + textBox2.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "'," + textBox4.Text + "," + textBox5.Text + "," + textBox5.Text + ")", xConn).ExecuteNonQuery();
            xConn.Close();

            textBox1.Text = "";
            textBox2.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";

            MessageBox.Show("Books Added Sucessfully");

        }

        private void Add_Books_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
