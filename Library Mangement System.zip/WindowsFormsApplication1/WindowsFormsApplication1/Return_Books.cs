﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Return_Books : Form
    {
        private SqlConnection xConn;
        public Return_Books()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;   
            fill_grid(Convert.ToInt32(textBox1.Text) );
            

        }
        public void fill_grid(int ID)
        {
            xConn.Open();
            DataTable xTable=new DataTable();
            new SqlDataAdapter("Select * from Borrow_Books where Member_ID='"+ID.ToString() +"'and Return_date=''",xConn).Fill(xTable);
            dataGridView1.DataSource= xTable;
            xConn.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel3.Visible = true;
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from Borrow_Books where ID='"+i+"'", xConn).Fill(xTable);
            dataGridView1.DataSource = xTable;
            foreach (DataRow dr in xTable.Rows)
            {
                lbl_booksName.Text = dr["Books_Name"].ToString();
                lbl_issuedate.Text=dr["Borrow_Date"].ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            xConn.Open();
            int i;
            
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());

            new SqlCommand("Update Borrow_Books set Return_date='" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "' where ID='" + i + "'", xConn).ExecuteNonQuery();

            new SqlCommand("Update Books set Available_Quantity= Available_Quantity+1 where books_name='" + lbl_booksName.Text + "'", xConn).ExecuteNonQuery();

            MessageBox.Show("Book Returned");
            
            panel3.Visible = true;
            xConn.Close();
            fill_grid(Convert.ToInt32(textBox1.Text));
            
        }
    }
}
