﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Login : Form
    {
        private SqlConnection xConn;
        int count = 0;
        public Login()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
            
        }
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             
            xConn.Open();
            DataTable xTable=new DataTable();
            new SqlDataAdapter("Select * from librarian where User_Name ='" + textBox1.Text + "' and  Password ='" + textBox2.Text + "'",xConn).Fill(xTable);
            count = Convert.ToInt32(xTable.Rows.Count.ToString());       
            if(count==0)
            {
               MessageBox.Show("Username and Password does not match");
            }
            else
            {
                this.Hide();
                MDI_user mu = new MDI_user();
                mu.Show();           
            }
            xConn.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
