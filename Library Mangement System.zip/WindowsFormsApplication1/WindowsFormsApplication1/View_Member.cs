﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class View_Member : Form
    {
        private SqlConnection xConn;
        
        public View_Member()
        {
            InitializeComponent();
            xConn = new SqlConnection(@"Data Source=LAPTOP-PT4C3P0K\SQLEXPRESS;Initial Catalog=Library_Management;Integrated Security=True;Pooling=False");
        }
        private void View_Member_Load(object sender, EventArgs e)
        {
            disp();          
        }
        public void disp()
        {
            xConn.Open();
            int i = 0;

            DataTable xTable = new DataTable();
            new SqlDataAdapter("select * from Member ", xConn).Fill(xTable);
            xGrid.DataSource = xTable;


            xConn.Close();
        }
        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {            
            try
            {
                xGrid.Columns.Clear();
                xGrid.Refresh();
                int i = 0;
                xConn.Open();
                DataTable xTable = new DataTable();
                new SqlDataAdapter("select * from Member where Member_Name like('%"+textBox1.Text+"%') ", xConn).Fill(xTable);
                xGrid.DataSource = xTable;
                xConn.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
                textBox1.Text = "";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            try
            {

                xConn.Open();

                int ID = Convert.ToInt32(xGrid.CurrentRow.Cells[0].Value.ToString());
                pictureBox1.Load("Images/Members//" + ID + ".jpg");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            xConn.Close();
        }
        private void xGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel1.Visible = true;
            int i;
            xConn.Open();         
            DataTable xTable = new DataTable();
            i = Convert.ToInt32(xGrid.SelectedCells[0].Value.ToString());
            new SqlDataAdapter("select * from Member where id="+i+"", xConn).Fill(xTable);
            foreach (DataRow dr in xTable.Rows)
            {
                Member_Name .Text = dr["Member_Name"].ToString();
                Member_Contact.Text = dr["Member_Contact"].ToString();
                Member_Email.Text = dr["Member_Email"].ToString();
                Address.Text = dr["Address"].ToString();
                dateTimePicker1.Value = Convert.ToDateTime(dr["Joining_Date"].ToString());
                dateTimePicker2.Value = Convert.ToDateTime(dr["Expiry_Date"].ToString());
            }
            xConn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int i;
            i = Convert.ToInt32(xGrid.SelectedCells[0].Value.ToString());
            try
            {
                xConn.Open();
                new SqlCommand(" update Member set Member_Name ='" + Member_Name.Text + "',Member_Contact='" + Member_Contact.Text + "',Member_Email='" + Member_Email.Text + "',Address='" + Address.Text + "',Joining_Date='" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "',Expiry_Date='" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "' where id=" + i + "", xConn).ExecuteNonQuery();
                xConn.Close();
                disp();
                MessageBox.Show("Record updated successfully");
                panel1.Visible = false;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void xGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     }
}